/*
import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;// Get the header value (assuming header name is 'text')
def Message processData(Message message) {   
def headerText = message.getHeader(java.lang.String "text")
def bodyText = message.getBody( java.lang.String)
if (headerText && bodyText.contains(".")) {
    // Split the body at the periods and insert the header text after each period
    def updatedBodyText = bodyText.split("\\.").join(". " + headerText + " ")
    
    // Set the modified body back to the message
    message.setBody(updatedBodyText)
} else {
    // If no periods are found, or if headerText is null, do nothing or log a message
    message.setBody(bodyText)  // Optionally, you can keep the original body
}

// Return the message so that it can be passed to the next step in the integration flow
return message;
}
*/
import com.sap.gateway.ip.core.customdev.util.Message;

import java.util.HashMap;
 
def Message processData(Message message) {


    def body = message.getBody(String)

    //def insertedText = message.getProperty("inputText") ?: ""  

    message.setProperty("Debug_Body", body)  

    def splitBody = body.split("\\.")

    def updatedBody = ""

    splitBody.eachWithIndex { segment, index ->

        if (segment.trim() != "") {  

            updatedBody += segment.trim() + "."

            if (index < splitBody.size() - 1) {

                updatedBody += "\n" //+ insertedText + "\n"

            }

        }

    }


    message.setBody(updatedBody.trim())  

    message.setProperty("Debug_UpdatedBody", updatedBody.trim())

    return message

}

 