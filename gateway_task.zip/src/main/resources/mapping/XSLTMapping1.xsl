<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" version="3.0"> 
<xsl:output encoding="UTF-8" method="xml" version="1.0"/>   
<xsl:template match="*">    
<xsl:element name="{local-name()}" >     
<xsl:apply-templates select="@* | node()"/>   
</xsl:element>	
</xsl:template>		
<!--<xsl:template match="@">
<xsl:attribute name="{local-name()}" >
<xsl:value-of 
</xsl:attribute>
</xsl:template>	    
<xsl:template match="comment()|text() | processing-instruction()">   
<xsl:copy/>	
</xsl:template>	-->
</xsl:stylesheet>
