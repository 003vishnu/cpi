import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Retrieve the 'belnr' property from the exchange
    def belnr = message.getProperty("BELNR")
    
    // Check if 'belnr' is present (not null and not empty)
    if (belnr != null && !belnr.toString().trim().isEmpty()) {
        // Set 'belnr_check' to 1 if 'belnr' is present
        message.setProperty("belnr_check", '111')
    } else {
        // Set 'belnr_check' to 0 if 'belnr' is null or empty
        message.setProperty("belnr_check", '999')
    }
    
    return message
}
