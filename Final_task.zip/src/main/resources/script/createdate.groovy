import com.sap.it.api.mapping.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/* 
Example function to retrieve headers or properties from the mapping context 
def String customFunc1(String P1, String P2, MappingContext context) {
    String value1 = context.getHeader(P1);
    String value2 = context.getProperty(P2);
    return value1 + value2;
}

Example function to work with input/output arrays and mapping context 
def void custFunc2(String[] is, String[] ps, Output output, MappingContext context) {
    String value1 = context.getHeader(is[0]);
    String value2 = context.getProperty(ps[0]);
    output.addValue(value1);
    output.addValue(value2);
}
*/

def String customFunc(String arg1) {
    // Parse arg1 as a format specifier or default to "yyyy-MM-dd"
    String format = arg1 != null && !arg1.trim().isEmpty() ? arg1 : "yyyy-MM-dd";
    try {
        // Get today's date
        LocalDate today = LocalDate.now();

        // Subtract 10 days
        LocalDate date10DaysBack = today.minusDays(10);

        // Format the date
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        return date10DaysBack.format(formatter);
    } catch (Exception e) {
        // Handle invalid formats gracefully
        return "Invalid format: " + arg1;
    }
}
